import flet as ft

def dashboard_admin(page: ft.Page):
    stats = ft.Row([
        ft.Container(ft.Text("Servicios: 12", color="white"), bgcolor="gray", padding=20, border_radius=8),
        ft.Container(ft.Text("Eventos: 8", color="white"), bgcolor="gray", padding=20, border_radius=8),
        ft.Container(ft.Text("Usuarios: 25", color="white"), bgcolor="gray", padding=20, border_radius=8),
        ft.Container(ft.Text("Mensajes: 5", color="white"), bgcolor="gray", padding=20, border_radius=8),
    ], alignment="center", spacing=10)

    return ft.Container(
        expand=True,
        bgcolor="black",
        alignment=ft.alignment.center,
        content=ft.Column([
            ft.Image(src="assets/logo.png", width=150, height=150),
            ft.Text("Dashboard Administrador", size=24, weight="bold", color="white"),
            stats,
            ft.Text("Calendario - Julio 2026", color="white"),
            ft.Text("Actividad reciente", color="white"),
        ], alignment="center", spacing=15)
    )

